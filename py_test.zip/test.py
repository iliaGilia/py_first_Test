from tools.numbers import col, comp, simp

print(simp.addNum(1,2))
print(simp.subtractNum(2,1))
print(comp.isPal(11311))
print(comp.isPal(11351))
print(comp.sumOfDigits(3552))
arr1 = [1,2,3]
arr2 = ['yosi','cars','repair']
print(col.myzip(arr1,arr2))