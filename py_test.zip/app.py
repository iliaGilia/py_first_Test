from tools.numbers import comp, simp

hasUsedSimp = False

while True:
    try:
        chosenFunction = int(input("1 to add, 2 to subtract, 3 to sum of digits, 4 to check palindrome or 5 to end: "))
    except ValueError:
        print("invalid input please enter a number")
        break
        
    if int(chosenFunction) == 1:
        try:
            num1 = int(input("Enter first num: "))
            num2 = int(input("Enter second num: "))
        except ValueError:
            print("invalid input please enter a number")
            break
        print("The answer is " + str(simp.addNum(num1, num2)))
        hasUsedSimp = True
        
    elif int(chosenFunction) == 2:
        try:
            num1 = int(input("Enter first num: "))
            num2 = int(input("Enter second num: "))
        except ValueError:
            print("invalid input please enter a number")
            break
        print("The answer is " + str(simp.subtractNum(num1, num2)))
        hasUsedSimp = True
        
    elif int(chosenFunction) == 5:
        print("Thank you for using my functions")
        break
        
    elif hasUsedSimp:
        if int(chosenFunction) == 3:
            try:
                num1 = int(input("Enter a number: "))
            except ValueError:
                print("invalid input please enter a number")
                break
            print("The sum of " + str(num1) + " is " + str(comp.sumOfDigits(num1)))
        elif int(chosenFunction) == 4:
            try:
                num1 = int(input("Enter a number: "))
            except ValueError:
                print("invalid input please enter a number")
                break
            print(str(num1) + " is a " + str(comp.isPal(num1)) + " palindrome")
            
    elif not hasUsedSimp and (int(chosenFunction) == 3 or int(chosenFunction) == 4):
        print("You can only use 3 and 4 after using at least once 1 or 2 functions")
