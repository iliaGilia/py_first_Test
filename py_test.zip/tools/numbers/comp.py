def sumOfDigits(num1):## פונקציה מקבלת מספר הופכת את המספר לסטרינג ומחזירה את הסכום של כל המספרים במספר
    digits = [int(i) for i in str(num1)]
    return sum(digits)
def isPal(num1):## פונקציה מקבל מספר הופכת אותו לסטרינג ואז מבצעת בדיקה האם הסטרינג ההפוך שלו זהה לסטרינג אם כן מחזיר נכון אם לא מחזיר לא נכון
    reversedNum1 = str(num1)
    if reversedNum1 == reversedNum1[::-1]:return True
    else: return False