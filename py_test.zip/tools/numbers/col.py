def myzip(arr1,arr2):# פונקציה שמקבלת שני מארכים ומשלבת אותם לפי המיקום שלהם ומחזירה את התוצאה המשולבת 
 result = []
 for i in range(len(arr1)):
    result.append((arr1[i], arr2[i]))
 return result
