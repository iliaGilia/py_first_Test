def addNum(num1,num2):  ##הפונקציה מקבלת שני מספרים ומחברת אותם מחזירה את התוצאה
    return int(num1) + int(num2)
def subtractNum(num1,num2): ## הפונקציה מקבלת שני מספרים ומחסרת אותם מחזירה את התוצאה
    return int(num1) - int(num2)